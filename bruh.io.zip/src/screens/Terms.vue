<template>
	<div class="screen terms-and-conditions">
	    <Panel class="terms-panel" :title="t('navTermsButtonText')">
			<template #panel-content>
				<pre class="preformatted">
<h1>TERMS OF USE</h1>
<h3>Last Updated: April 27, 2021</h3>
These Terms of Use (“Terms”) apply to your access to and use of the websites, applications and other online products and services including our games (collectively, our “Services”) provided by Other Ocean group of companies: Other Ocean Group Canada Limited, Sculpin QA Limited, Other Ocean Interactive NL Limited and Other Ocean Group Inc. (collectively referred to as “Other Ocean” or “we”). Please read these Terms carefully before you start to use the Services. By using the Services, you accept and agree to be bound and abide by these Terms of Service. If you do not want to agree to these Terms of Service, you must not use the Services. In addition to these Terms, software or services that are included in or otherwise made available to you through the Services may be subject to separate agreement between you and Other Ocean, such as end user license agreements. If these Terms are inconsistent with any such agreements, those agreements will control. Please refer to our Privacy Policy for information about how we collect, use and disclose information about you.

<h2>Changes to the Terms of Service</h2>
We may update these Terms from time to time; you should check this page regularly to take notice of any changes. Your continued use of the Services following the posting of revised Terms means that you accept and agree to the changes.

<h2>Eligibility</h2>
You must be at least 13 years of age to access or use our Services or 16 if you live in the European Economic Area and want to access or use our Services. If you are under 18 years of age (or the age of legal majority where you live), you may only access or use our Services under the supervision of a parent or legal guardian who agrees to be bound by these Terms. If you are a parent or legal guardian of a user under the age of 18 (or the age of legal majority where you live), you (i) agree to be bound by these Terms and any applicable additional terms and (ii) are fully responsible for the acts or omissions of such user in connection with our Services. The Services are for personal use only. organizations, companies, or businesses may not use the Services for any purpose. You may not use the Services if you have previously been suspended or removed from the Services. Certain Services may not be available in all jurisdictions, and we reserve the right to impose additional eligibility requirements.

<h2>Accessing the Services and Account Security</h2>
We may withdraw or amend the Services, and any related service or content, or restrict access (including by means of cancellation, termination, or modification, or suspension of a user account) to all or certain users (including you) without notice and without liability to you. Additionally, due to your geographic location, the Services or some of their features, services, or content may be unavailable to you. To access certain Services, you will be asked to provide registration details or other information, and in order to use such resources, all the information you provide must be correct, current, and complete. From time to time, in order to access the Services or certain games, services, or functionality, Other Ocean may require some or all users to download updated or additional software. The terms of use of such software may be subject to separate agreement between you and Other Ocean. If you choose, or are provided with, a user name, password, or any other piece of information as part of our security procedures, you must treat such information as confidential (other than user name), and you must not disclose it to others. You must immediately notify Other Ocean (via contact@otherocean.com) of any unauthorized use of your user name or password or any other breach of security. You should use particular caution when accessing your account from a public or shared computer so that others are not able to view or record your password or other personal information. You may only access the Services through your own account. Users do not own their accounts, and gifting or otherwise transferring of accounts or access keys is prohibited.

<h2>Intellectual Property Rights</h2>
The Services, including all content, features, and functionality thereof, are owned by Other Ocean, its licensors, or other providers of such material and are protected by United States and international copyright, trademark, patent, and other intellectual property or proprietary rights laws. You are permitted to use the Services for your personal, non-commercial use only or legitimate business purposes related to your role as a current or prospective customer of Other Ocean. Except as provided below, you must not copy, modify, create derivative works of, publicly display, publicly perform, republish, or transmit any of the material obtained through the Services, or delete, or alter any copyright, trademark, or other proprietary rights notices from copies of materials from the Services. However, if you are otherwise in compliance with these Terms, you are permitted to use, elsewhere and on other websites, an unaltered copy of portions of the content that is publicly available on the Website for the limited, non-commercial purpose of discussing such content. You must not reproduce, sell, or exploit for any commercial purposes any part of the Services, access to the Services or use of the Services or any services or materials available through the Services. For clarity, the foregoing permissions are limited to the Services, and no rights are granted with respect to any servers, computers, or databases associated with the Services.

<h2>Prohibited Uses</h2>
You may use the Services only for lawful purposes and in accordance with these Terms of Service. You agree not to access or use the Services for any purpose that is illegal or beyond the scope of the Services’ intended use (in Other Ocean’s sole judgment).

<h2>User Contributions</h2>
The Services contain various forums, networks, and other interactive features that allow you to post, submit, publish, display, or transmit to Other Ocean and other users (“Post”) content or materials (“User Contributions”) on or through the Services. All User Contributions must comply with the following content standards: User Contributions must not be illegal, fraudulent, deceptive, obscene, threatening, defamatory, invasive of privacy, infringing of intellectual property rights, or otherwise injurious to third parties or objectionable, and must not consist of or contain software viruses, commercial solicitation, chain letters, mass mailings, or any form of “spam.” Any User Contribution that you Post will be considered non-confidential and non-proprietary, and you grant Other Ocean a nonexclusive, royalty-free, perpetual, irrevocable, and fully sublicensable right to use, copy, reproduce, modify, adapt, publish, translate, create derivative works from, distribute, and display such User Contribution throughout the world in any media; however, Other Ocean will only share personal information that you provide in accordance with Other Oceans’ Privacy Notice found at here. You represent and warrant that you own or otherwise control all of the rights to the User Contributions that you Post at the time of Posting; that the User Contributions are accurate and not fraudulent or deceptive; and that the User Contributions do not violate these Terms or the rights (intellectual property rights or otherwise) of any third party, and will not cause injury to any person or entity. You understand that your User Contributions may be copied by other Services users and discussed on and outside of the Services, and if you do not have the right to submit User Contributions for such use, it may subject you to liability. Other Ocean takes no responsibility and assumes no liability for any content Posted by you or any third party. Other Ocean has the right but not the obligation to monitor and edit or remove any User Contributions. Other Ocean also has the right to terminate your access to all or part of the Services for any or no reason, including without limitation, any violation of these Terms.

<h2>Community Guidelines</h2>

     * You are solely responsible for your conduct while accessing or using our Services, and you will not:
         * Violate any applicable law, contract, intellectual property or other third-party right or commit a tort;
         * Engage in any abusive, disrespectful, harassing, threatening, intimidating, violent, predatory or stalking conduct;
         * Use or attempt to use another user’s account without authorization from that user and Other Ocean;
         * Use our Services in any manner that could interfere with, disrupt, spam, negatively affect or inhibit other users from fully enjoying our Services or that could damage, disable, overburden or impair the functioning of our Services in any manner;
         * Attempt to circumvent any content-filtering techniques we employ or attempt to access or tamper with any feature, content or area of our Services that you are not authorized to access, which includes any attempt to probe, scan, or test the vulnerability of any system or network, or breach or circumvent any security or authentication measures;
         * Develop or use any applications that interact with our Services without our prior written consent;
         * Sell, rent or purchase account interactions (such as selling, renting or purchasing followers, re-sharing a post, likes, etc.)
         * Use any data mining, scraping, robots or similar data gathering or extraction methods Bypass or ignore instructions contained in any robots.txt file we provide that controls automated access to portions of our Services; or
         * Use our Services for any illegal or unauthorized purpose, or engage in, encourage or promote any activity that violates these Terms.

     * You may also only post or otherwise share User Content that is non-confidential and you have all necessary rights to disclose. You may not create, post, store or share any User Content that:
         * Is unlawful, libelous, defamatory, obscene, pornographic, discriminatory, indecent, lewd, suggestive, harassing, bullying, threatening, invasive of privacy or publicity rights, abusive, inflammatory or fraudulent;
         * Includes content that directly attacks, threatens, or incites harm against other people based on their race, ethnicity, national origin, religious affiliation, sexual orientation, sex, gender, gender identity, disabilities or diseases;
         * Would constitute, encourage or provide instructions for a criminal offense, promote selfinjury or suicide, violate the rights of any party or otherwise create liability or violate any local, state, national or international law;
         * May infringe any patent, trademark, trade secret, copyright or other intellectual or proprietary right of any party;
         * Contains or depicts any statements, remarks or claims that do not reflect your honest views and experiences or are otherwise false or misleading;
         * Contains multiple unrelated updates to a topic using a hashtag (#) or other similar search mechanism, trending or popular topic, or promoted trend;
         * Contains duplicative content over multiple accounts or duplicate updates on one account; Contains duplicate replies or mentions or unsolicited replies or mentions;
         * Impersonates, or misrepresents your affiliation with, any person or entity;
         * Contains any unsolicited promotions, political campaigning, advertising or solicitations;
         * Contains any private or personal information of a third party without such third party’s consent;
         *  * Contains any viruses, malware, corrupted data or other harmful, disruptive or destructive files or content; or
         * Is, in our sole judgment, objectionable or that restricts or inhibits any other person from using or enjoying our Services, or that may expose Other Ocean or others to any harm or liability of any type.

     * Although we have no obligation to screen, edit or monitor User Content, we may delete or remove User Content at any time and for any reason.

<h2>Linking</h2>
You may link to publicly available portions of the Services if you do so in a way that is fair and does not damage or take advantage of our reputation, but you must not establish a link in such a way as to suggest any form of association, approval, or endorsement on our part. The Services must not be framed on any other website or service. We reserve the right to withdraw linking permission without notice. If the Services contain links to other sites and resources provided by third parties, these links are provided for your convenience only. We have no control over the contents of those sites or resources, and accept no responsibility for them or for any loss or damage that may arise from your use of them.

<h2>Disclaimer of Warranties</h2>
The Services and all information, content, materials, products (including software), and other services included on or otherwise made available to you through the Services are provided by Other Ocean on an “as is” and “as available” basis. Other Ocean makes no representations or warranties of any kind, express or implied, as to the operation of the Services, or the information, content, materials, products (including software), or other services included on or otherwise made available to you through the Services. You expressly agree that your use of the Services is at your sole risk. To the full extent permissible by law, Other Ocean disclaims all warranties, express or implied, including, but not limited to, implied warranties of merchantability and fitness for a particular purpose. Other Ocean does not warrant that the Services, information, content, materials, products (including software) or other services included on or otherwise made available to you through the Services, Other Ocean’s servers, or electronic communications sent from Other Ocean are free of viruses or other harmful components.

<h2>Limitation of Liability</h2>
To the full extent permissible by law, Other Ocean will not be liable for any loss of profits or any indirect, incidental, punitive, special or consequential damages arising out of or in connection with this Agreement.

<h2>Indemnification</h2>
You agree to defend, indemnify, and hold harmless Other Ocean, its affiliates, and licensors, and their respective officers, directors, employees, contractors, agents, licensors, and suppliers from and against any claims, liabilities, damages, judgments, awards, losses, costs, expenses, or fees (including reasonable attorneys’ fees) resulting from your User Contributions or violation of these Terms.

<h2>Governing Law and Jurisdiction</h2>
This Agreement shall be construed (without regard to conflicts or choice of law principles) under the laws of the province of Prince Edward Island, except as governed by federal law. Unless expressly waived by Licensor in writing for the particular instance or contrary to local law, the sole and exclusive jurisdiction and venue for actions related to the subject matter hereof shall be the provincial and federal courts located in Licensor's principal corporate place of business (Prince Edward Island, Canada) You and Licensor consent to the jurisdiction of such courts and agree that process may be served in the manner provided herein for giving of notices or otherwise as allowed by Prince Edward Island or federal law. You and Licensor agree that the UN Convention on Contracts for the International Sale of Goods (Vienna, 1980) shall not apply to this Agreement or to any dispute or transaction arising out of this Agreement.

<h2>Contact</h2>
If you have any questions or concerns regarding the Services or these Terms, please contact Other Ocean at contact@otherocean.com
				</pre>
			</template>
	    </Panel>
	</div>
</template>

<script>
import { mapGetters } from "vuex"
import Panel from "../reusable-components/Panel"

export default {
	name: "Terms and Conditions",
	components: {
		Panel,
	},
	computed: {
		...mapGetters("i18n", ["t"]),
	},
}
</script>

<style lang="scss" scoped>
.terms-and-conditions {
	.terms-panel {
		display: flex;
		min-width: 750px;
		max-width: 85%;
		min-height: 300px;
		max-height: 85%;
		position: relative;

		.preformatted {
			overflow-x: auto;
			white-space: pre-wrap;
			white-space: -moz-pre-wrap;
			white-space: -pre-wrap;
			white-space: -o-pre-wrap;
			word-wrap: break-word;
		}
	}
}
</style>
